package com.example.app_proto_02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;

public class shapes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shapes);

        ConstraintLayout ShapeView = findViewById(R.id.ShapesActivity);                               //Gradient background
        AnimationDrawable animationDrawable = (AnimationDrawable) ShapeView.getBackground();          //Gradient background
        animationDrawable.setEnterFadeDuration(2000);                                                 //Gradient background
        animationDrawable.setExitFadeDuration(4000);                                                  //Gradient background
        animationDrawable.start();                                                                    //Gradient background
    }

    //---Shapes button click
    public void Circle(View view)
    {

    }
    public void Square(View view)
    {

    }
    public void Triangle(View view)
    {

    }public void Rectangle(View view)
    {

    }public void Oval(View view)
    {

    }public void Star(View view)
    {

    }
    public void Diamond(View view)
    {

    }
    public void Heart(View view)
    {

    }
    public void onBackClick(View view)
    {
        startActivity(new Intent(shapes.this, scroll_options.class));
    }
    //---Shapes button end
}
