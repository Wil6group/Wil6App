package com.example.app_proto_02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class numbers_test_level_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numbers_test_level_2);
    }
}
