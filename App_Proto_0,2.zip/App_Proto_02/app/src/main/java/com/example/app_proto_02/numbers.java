package com.example.app_proto_02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;

public class numbers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numbers);

        ConstraintLayout NumView = findViewById(R.id.NumbersActivity);                                //Gradient background
        AnimationDrawable animationDrawable = (AnimationDrawable) NumView.getBackground();            //Gradient background
        animationDrawable.setEnterFadeDuration(2000);                                                 //Gradient background
        animationDrawable.setExitFadeDuration(4000);                                                  //Gradient background
        animationDrawable.start();                                                                    //Gradient background
    }

    //---Numbers button click
    public void One(View view)
    {

    }
    public void Two(View view)
    {

    }
    public void Three(View view)
    {

    }public void Four(View view)
    {

    }
    public void Five(View view)
    {

    }public void Six(View view)
    {

    }
    public void Seven(View view)
    {

    }
    public void Eight(View view)
    {

    }
    public void Nine(View view)
    {

    }
    public void Ten(View view)
    {

    }
    public void onBackClick(View view)
    {
        startActivity(new Intent(numbers.this, scroll_options.class));
    }
    //---Numbers button end
}
