package com.example.app_proto_02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;

public class colours extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colours);

        ConstraintLayout ColView = findViewById(R.id.ColoursActivity);                                //Gradient background
        AnimationDrawable animationDrawable = (AnimationDrawable) ColView.getBackground();            //Gradient background
        animationDrawable.setEnterFadeDuration(2000);                                                 //Gradient background
        animationDrawable.setExitFadeDuration(4000);                                                  //Gradient background
        animationDrawable.start();                                                                    //Gradient background
    }

    //---Colours button click
    public void Blue(View view)
    {

    }
    public void Red(View view)
    {

    }
    public void Yellow(View view)
    {

    }public void Green(View view)
    {

    }public void Purple(View view)
    {

    }
    public void Pink(View view)
    {

    }
    public void Orange(View view)
    {

    }
    public void Brown(View view)
    {

    }
    public void Black(View view)
    {

    }
    public void Grey(View view)
    {

    }
    public void onBackClick(View view)
    {
        startActivity(new Intent(colours.this, scroll_options.class));
    }
    //---Colours button end
}
