package com.example.app_proto_02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class PicMatching extends AppCompatActivity { //Pic matching done by Shivaar. This Activity is in conjunction with ImageAdapter class.

    ImageView curView = null;
    private int countPair = 0;
    final int[] drawable = new int[]{R.drawable.chicken, R.drawable.dog, R.drawable.cat, R.drawable.butterfly, R.drawable.bee, R.drawable.bird, R.drawable.fish, R.drawable.sheep};

    int[] pos = {0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7};
    int currentPos = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pic_matching);

        RelativeLayout PicMatchView = findViewById(R.id.PicMatchActivity);                            //Gradient background
        AnimationDrawable animationDrawable = (AnimationDrawable) PicMatchView.getBackground();       //Gradient background
        animationDrawable.setEnterFadeDuration(2000);                                                 //Gradient background
        animationDrawable.setExitFadeDuration(4000);                                                  //Gradient background
        animationDrawable.start();                                                                    //Gradient background

        GridView gridView = (GridView) findViewById(R.id.gridView);
        ImageAdapter imageAdapter = new ImageAdapter(this);
        gridView.setAdapter(imageAdapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (currentPos<0)
                {
                    currentPos = position;
                    curView = (ImageView)view;
                    ((ImageView)view).setImageResource(drawable[pos[position]]);
                }else
                    {
                        if (currentPos == position)
                        {
                            ((ImageView)view).setImageResource(R.drawable.questionmark);
                        }else if(pos[currentPos] != pos[position])
                            {
                                curView.setImageResource(R.drawable.questionmark);
                                Toast.makeText(PicMatching.this, "No Match", Toast.LENGTH_SHORT).show();
                            }else
                                {
                                    ((ImageView)view).setImageResource(drawable[pos[position]]);
                                    countPair++;

                                    if (countPair==0)
                                    {
                                        Toast.makeText(PicMatching.this, "You Win!", Toast.LENGTH_SHORT).show();
                                    }
                                }
                        currentPos=-1;
                    }
            }
        });
    }

    public void onBackClick(View view)//In xml layout click on back button and set this method in the OnClick under attributes
    {
        startActivity(new Intent(PicMatching.this, scroll_options.class));
    }
}