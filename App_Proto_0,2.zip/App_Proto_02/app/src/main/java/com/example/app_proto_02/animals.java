package com.example.app_proto_02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;

public class animals extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animals);

        ConstraintLayout AniView = findViewById(R.id.AnimalActivity);                                 //Gradient background
        AnimationDrawable animationDrawable = (AnimationDrawable) AniView.getBackground();            //Gradient background
        animationDrawable.setEnterFadeDuration(2000);                                                 //Gradient background
        animationDrawable.setExitFadeDuration(4000);                                                  //Gradient background
        animationDrawable.start();                                                                    //Gradient background
    }

    //---Animals button click
    public void Bird(View view)
    {

    }
    public void Bee(View view)
    {

    }
    public void Butterfly(View view)
    {

    }
    public void Cat(View view)
    {

    }
    public void Dog(View view)
    {

    }
    public void Chicken(View view)
    {

    }
    public void Sheep(View view)
    {

    }
    public void Fish(View view)
    {

    }
    public void onBackClick(View view) {
        startActivity(new Intent(animals.this, scroll_options.class));
    }
    //---Animals button click end
}
